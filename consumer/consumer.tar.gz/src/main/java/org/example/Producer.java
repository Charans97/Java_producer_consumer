package org.example;

public class Producer {
}
